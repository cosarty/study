<script setup lang="ts">
import HelloWorld from './components/HelloWorld.vue'
</script>

<template>

  <HelloWorld />
</template>

<style scoped>

</style>
